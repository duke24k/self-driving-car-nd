#!/bin/bash
# Script to run particle filter!
#
# Written by Tiffany Huang, 12/14/2016
#

# Run particle filter
cd ./build
./particle_filter
